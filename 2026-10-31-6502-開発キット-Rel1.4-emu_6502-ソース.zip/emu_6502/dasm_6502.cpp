//  dasm_6502.cpp  �t�A�b�Z���u��
//  ��ҁF���{��
//

#include <stdio.h>
#include <stdlib.h>


int dasm(FILE *fp, int pc, unsigned char *mem){
	int op, tmp;
	unsigned char code;

	code = mem[pc++];
	switch(code){
	case 0xa9:                          // LDA #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDA #$%02x\n", pc-2, code, op, op);
		break;
	case 0xa5:                          // LDA $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDA $%02x\n", pc-2, code, op, op);
		break;
	case 0xb5:                          // LDA $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDA $%02x,X\n", pc-2, code, op, op);
		break;
	case 0xad:                          // LDA $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LDA $%04x\n", pc-3, code, op, op);
		break;
	case 0xbd:                          // LDA $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LDA $%04x,X\n", pc-3, code, op, op);
		break;
	case 0xb9:                          // LDA $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LDA $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0xa1:                          // LDA ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDA ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0xb1:                          // LDA ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDA ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0xa2:                          // LDX #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDX #$%02x\n", pc-2, code, op, op);
		break;
	case 0xa6:                          // LDX $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDX $%02x\n", pc-2, code, op, op);
		break;
	case 0xb6:                          // LDX $10,Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDX $%02x,Y\n", pc-2, code, op, op);
		break;
	case 0xae:                          // LDX $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LDX $%04x\n", pc-3, code, op, op);
		break;
	case 0xbe:                          // LDX $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LDX $%04x,Y\n", pc-3, code, op, op);
		break;
	;
	case 0xa0:                          // LDY #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDY #$%02x\n", pc-2, code, op, op);
		break;
	case 0xa4:                          // LDY $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDY $%02x\n", pc-2, code, op, op);
		break;
	case 0xb4:                          // LDY $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LDY $%02x,X\n", pc-2, code, op, op);
		break;
	case 0xac:                          // LDY $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LDY $%04x\n", pc-3, code, op, op);
		break;
	case 0xbc:                          // LDY $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LDY $%04x,X\n", pc-3, code, op, op);
		break;
	;
	case 0x85:                          // STA $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STA $%02x\n", pc-2, code, op, op);
		break;
	case 0x95:                          // STA $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STA $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x8d:                          // STA $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x STA $%04x\n", pc-3, code, op, op);
		break;
	case 0x9d:                          // STA $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x STA $%04x,X\n", pc-3, code, op, op);
		break;
	case 0x99:                          // STA $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x STA $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0x81:                          // STA ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STA ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0x91:                          // STA ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STA ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0x86:                          // STX $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STX $%02x\n", pc-2, code, op, op);
		break;
	case 0x96:                          // STX $10,Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STX $%02x,Y\n", pc-2, code, op, op);
		break;
	case 0x8e:                          // STX $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x STX $%04x\n", pc-3, code, op, op);
		break;
	;
	case 0x84:                          // STY $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STY $%02x\n", pc-2, code, op, op);
		break;
	case 0x94:                          // STY $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   STY $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x8c:                          // STY $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x STY $%04x\n", pc-3, code, op, op);
		break;
	;
	case 0x69:                          // ADC #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ADC #$%02x\n", pc-2, code, op, op);
		break;
	case 0x65:                          // ADC $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ADC $%02x\n", pc-2, code, op, op);
		break;
	case 0x75:                          // ADC $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ADC $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x6d:                          // ADC $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ADC $%04x\n", pc-3, code, op, op);
		break;
	case 0x7d:                          // ADC $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ADC $%04x,X\n", pc-3, code, op, op);
		break;
	case 0x79:                          // ADC $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ADC $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0x61:                          // ADC ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ADC ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0x71:                          // ADC ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ADC ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0xe9:                          // SBC #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   SBC #$%02x\n", pc-2, code, op, op);
		break;
	case 0xe5:                          // SBC $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   SBC $%02x\n", pc-2, code, op, op);
		break;
	case 0xf5:                          // SBC $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   SBC $%02x,X\n", pc-2, code, op, op);
		break;
	case 0xed:                          // SBC $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x SBC $%04x\n", pc-3, code, op, op);
		break;
	case 0xfd:                          // SBC $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x SBC $%04x,X\n", pc-3, code, op, op);
		break;
	case 0xf9:                          // SBC $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x SBC $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0xe1:                          // SBC ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   SBC ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0xf1:                          // SBC ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   SBC ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0x29:                          // AND #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   AND #$%02x\n", pc-2, code, op, op);
		break;
	case 0x25:                          // AND $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   AND $%02x\n", pc-2, code, op, op);
		break;
	case 0x35:                          // AND $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   AND $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x2d:                          // AND $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x AND $%04x\n", pc-3, code, op, op);
		break;
	case 0x3d:                          // AND $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x AND $%04x,X\n", pc-3, code, op, op);
		break;
	case 0x39:                          // AND $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x AND $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0x21:                          // AND ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   AND ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0x31:                          // AND ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   AND ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0x09:                          // ORA #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ORA #$%02x\n", pc-2, code, op, op);
		break;
	case 0x05:                          // ORA $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ORA $%02x\n", pc-2, code, op, op);
		break;
	case 0x15:                          // ORA $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ORA $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x0d:                          // ORA $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ORA $%04x\n", pc-3, code, op, op);
		break;
	case 0x1d:                          // ORA $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ORA $%04x,X\n", pc-3, code, op, op);
		break;
	case 0x19:                          // ORA $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ORA $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0x01:                          // ORA ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ORA ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0x11:                          // ORA ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ORA ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0x49:                          // EOR #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   EOR #$%02x\n", pc-2, code, op, op);
		break;
	case 0x45:                          // EOR $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   EOR $%02x\n", pc-2, code, op, op);
		break;
	case 0x55:                          // EOR $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   EOR $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x4d:                          // EOR $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x EOR $%04x\n", pc-3, code, op, op);
		break;
	case 0x5d:                          // EOR $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x EOR $%04x,X\n", pc-3, code, op, op);
		break;
	case 0x59:                          // EOR $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x EOR $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0x41:                          // EOR ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   EOR ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0x51:                          // EOR ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   EOR ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0xc9:                          // CMP #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CMP #$%02x\n", pc-2, code, op, op);
		break;
	case 0xc5:                          // CMP $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CMP $%02x\n", pc-2, code, op, op);
		break;
	case 0xd5:                          // CMP $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CMP $%02x,X\n", pc-2, code, op, op);
		break;
	case 0xcd:                          // CMP $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x CMP $%04x\n", pc-3, code, op, op);
		break;
	case 0xdd:                          // CMP $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x CMP $%04x,X\n", pc-3, code, op, op);
		break;
	case 0xd9:                          // CMP $1234,Y
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x CMP $%04x,Y\n", pc-3, code, op, op);
		break;
	case 0xc1:                          // CMP ($12,X)
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CMP ($%02x,X)\n", pc-2, code, op, op);
		break;
	case 0xd1:                          // CMP ($12),Y
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CMP ($%02x),Y\n", pc-2, code, op, op);
		break;
	;
	case 0xe0:                          // CPX #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CPX #$%02x\n", pc-2, code, op, op);
		break;
	case 0xe4:                          // CPX $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CPX $%02x\n", pc-2, code, op, op);
		break;
	case 0xec:                          // CPX $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x CPX $%04x\n", pc-3, code, op, op);
		break;
	;
	case 0xc0:                          // CPY #$10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CPY #$%02x\n", pc-2, code, op, op);
		break;
	case 0xc4:                          // CPY $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   CPY $%02x\n", pc-2, code, op, op);
		break;
	case 0xcc:                          // CPY $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x CPY $%04x\n", pc-3, code, op, op);
		break;
	;
	case 0xe6:                          // INC $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   INC $%02x\n", pc-2, code, op, op);
		break;
	case 0xf6:                          // INC $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   INC $%02x,X\n", pc-2, code, op, op);
		break;
	case 0xee:                          // INC $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x INC $%04x\n", pc-3, code, op, op);
		break;
	case 0xfe:                          // INC $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x INC $%04x,X\n", pc-3, code, op, op);
		break;
	;
	case 0xc6:                          // DEC $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   DEC $%02x\n", pc-2, code, op, op);
		break;
	case 0xd6:                          // DEC $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   DEC $%02x,X\n", pc-2, code, op, op);
		break;
	case 0xce:                          // DEC $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x DEC $%04x\n", pc-3, code, op, op);
		break;
	case 0xde:                          // DEC $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x DEC $%04x,X\n", pc-3, code, op, op);
		break;
	;
	case 0xe8:                          // INX
		fprintf(fp, "%04x %02x      INX\n", pc-1, code);
		break;
	case 0xc8:                          // INY
		fprintf(fp, "%04x %02x      INY\n", pc-1, code);
		break;
	case 0xca:                          // DEX
		fprintf(fp, "%04x %02x      DEX\n", pc-1, code);
		break;
	case 0x88:                          // DEY
		fprintf(fp, "%04x %02x      DEY\n", pc-1, code);
		break;
	;
	case 0x0a:                          // ASL A
		fprintf(fp, "%04x %02x      ASL A\n", pc-1, code);
		break;
	case 0x06:                          // ASL $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ASL $%02x\n", pc-2, code, op, op);
		break;
	case 0x16:                          // ASL $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ASL $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x0e:                          // ASL $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ASL $%04x\n", pc-3, code, op, op);
		break;
	case 0x1e:                          // ASL $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ASL $%04x,X\n", pc-3, code, op, op);
		break;
	;
	case 0x4a:                          // LSR  A
		fprintf(fp, "%04x %02x      LSR A\n", pc-1, code);
		break;
	case 0x46:                          // LSR  $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LSR $%02x\n", pc-2, code, op, op);
		break;
	case 0x56:                          // LSR  $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   LSR $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x4e:                          // LSR  $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LSR $%04x\n", pc-3, code, op, op);
		break;
	case 0x5e:                          // LSR  $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x LSR $%04x,X\n", pc-3, code, op, op);
		break;
	;
	case 0x2a:                          // ROL  A
		fprintf(fp, "%04x %02x      ROL A\n", pc-1, code);
		break;
	case 0x26:                          // ROL  $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ROL $%02x\n", pc-2, code, op, op);
		break;
	case 0x36:                          // ROL  $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ROL $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x2e:                          // ROL  $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ROL $%04x\n", pc-3, code, op, op);
		break;
	case 0x3e:                          // ROL  $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ROL $%04x,X\n", pc-3, code, op, op);
		break;
	;
	case 0x6a:                          // ROR A
		fprintf(fp, "%04x %02x      ROR A\n", pc-1, code);
		break;
	case 0x66:                          // ROR $10
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ROR $%02x\n", pc-2, code, op, op);
		break;
	case 0x76:                          // ROR $10,X
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   ROR $%02x,X\n", pc-2, code, op, op);
		break;
	case 0x6e:                          // ROR $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ROR $%04x\n", pc-3, code, op, op);
		break;
	case 0x7e:                          // ROR $1234,X
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x ROR $%04x,X\n", pc-3, code, op, op);
		break;
	;
	case 0xaa:                          // TAX
		fprintf(fp, "%04x %02x      TAX\n", pc-1, code);
		break;
	case 0xa8:                          // TAY
		fprintf(fp, "%04x %02x      TAY\n", pc-1, code);
		break;
	case 0x8a:                          // TXA
		fprintf(fp, "%04x %02x      TXA\n", pc-1, code);
		break;
	case 0x98:                          // TYA
		fprintf(fp, "%04x %02x      TYA\n", pc-1, code);
		break;
	;
	case 0xf0:                          // BEQ $1234 ... pc���� +127�`-128
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BEQ $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	case 0xd0:                          // BNE $1234
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BNE $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	case 0xb0:                          // BCS $1234
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BCS $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	case 0x90:                          // BCC $1234
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BCC $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	case 0x30:                          // BMI $1234
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BMI $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	case 0x10:                          // BPL $1234
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BPL $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	case 0x70:                          // BVS $1234
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BVS $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	case 0x50:                          // BVC $1234
		tmp = (char)mem[pc++];
		op = pc + tmp;
		fprintf(fp, "%04x %02x %02x   BVC $%04x\n", pc-2, code, tmp&0xff, op);
		break;
	;
	case 0x4c:                          // JMP $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x JMP $%04x\n", pc-3, code, op, op);
		break;
	case 0x6c:                          // JMP ($1234)
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x JMP ($%04x)\n", pc-3, code, op, op);
		break;
	case 0x20:                          // JSR $1234
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x JSR $%04x\n", pc-3, code, op, op);
		break;
	case 0x60:                          // RTS
		fprintf(fp, "%04x %02x      RTS\n", pc-1, code);
		break;
	;
	case 0x48:                          // PHA  ... push A
		fprintf(fp, "%04x %02x      PHA\n", pc-1, code);
		break;
	case 0x08:                          // PHP  ... push F
		fprintf(fp, "%04x %02x      PHP\n", pc-1, code);
		break;
	case 0x68:                          // PLA  ... pop A
		fprintf(fp, "%04x %02x      PLA\n", pc-1, code);
		break;
	case 0x28:                          // PLP  ... pop F
		fprintf(fp, "%04x %02x      PLP\n", pc-1, code);
		break;
	;
	case 0x18:                          // CLC
		fprintf(fp, "%04x %02x      CLC\n", pc-1, code);
		break;
	case 0x38:                          // SEC
		fprintf(fp, "%04x %02x      SEC\n", pc-1, code);
		break;
	case 0x58:                          // CLI
		fprintf(fp, "%04x %02x      CLI\n", pc-1, code);
		break;
	case 0x78:                          // SEI
		fprintf(fp, "%04x %02x      SEI\n", pc-1, code);
		break;
	case 0xb8:                          // CLV
		fprintf(fp, "%04x %02x      CLV\n", pc-1, code);
		break;
	case 0xd8:                          // CLD
		fprintf(fp, "%04x %02x      CLD\n", pc-1, code);
		break;
	case 0xf8:                          // (SED) NOP
		fprintf(fp, "%04x %02x      SED\n", pc-1, code);
		break;
	;
	case 0xea:                          // NOP
		fprintf(fp, "%04x %02x      NOP\n", pc-1, code);
		break;
	case 0x00:                          // BRK
		fprintf(fp, "%04x %02x      BRK\n", pc-1, code);
		break;
	case 0x02:                          // INT3
		fprintf(fp, "%04x %02x      INT3\n", pc-1, code);
		break;
	case 0x40:                          // RTI
		fprintf(fp, "%04x %02x      RTI\n", pc-1, code);
		break;
	case 0x24:                          // BIT zp
		op = mem[pc++];
		fprintf(fp, "%04x %02x %02x   BIT $%02x\n", pc-2, code, op, op);
		break;
	case 0x2c:                          // BIT abs
		op = *(unsigned short*)&mem[pc];
		pc += 2;
		fprintf(fp, "%04x %02x %04x BIT $%04x\n", pc-3, code, op, op);
		break;
	case 0x9a:                          // TXS
		fprintf(fp, "%04x %02x      TXS\n", pc-1, code);
	    break;
	case 0xba:                          // TSX
		fprintf(fp, "%04x %02x      TSX\n", pc-1, code);
	;
	default:
		fprintf(fp, "%04x %02x      DB $%02x\n", pc-1,code,code);
		break;
	}
	return pc;                           // normal end
}
