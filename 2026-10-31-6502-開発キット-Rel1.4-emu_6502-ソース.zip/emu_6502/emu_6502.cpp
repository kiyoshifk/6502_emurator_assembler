//  emu.cpp   �t�@�~�R��CPU�i6502�j�G�~�����[�^
//  ��ҁF���{��
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <conio.h>
#include <windows.h>

#include "dasm_6502.cpp"


#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comdlg32.lib")


unsigned char A, X, Y, sp;
unsigned short pc;
unsigned char mem[0x10000];
union flag{
	struct {
		unsigned int Cf : 1;   // Carry
		unsigned int Zf : 1;   // Zero
		unsigned int If : 1;   // Intterrupt Disable
		unsigned int Df : 1;   // Decimal
		unsigned int Bf : 1;   // Break
		unsigned int dmy : 1;
		unsigned int Vf : 1;   // Overflow
		unsigned int Nf : 1;   // Negative
	}bits;
	unsigned char f;
} P;
#define C P.bits.Cf
#define Z P.bits.Zf
#define I P.bits.If
#define D P.bits.Df
#define B P.bits.Bf
#define V P.bits.Vf
#define N P.bits.Nf


struct b_point{
	unsigned short flag;     // 0:���g�p�A1:�g�p��
	unsigned short code;
	unsigned short addr;
};
struct b_point b_point[3];
char linebuf[1024];
char *linebufp;
char symbuf[64];


int dasm(FILE *fp, int pc, unsigned char *mem);
unsigned char ppu_read(int addr);
void ppu_write(int addr, unsigned char data);


unsigned char ppu_read(int addr){
	if(addr==0xfff8){                   // �ꕶ������
		return _kbhit() ? _getch() : 0;
	}
	return mem[addr];
}


void ppu_write(int addr, unsigned char data){
	if(addr==0xfff6){                   // �ꕶ���o��
		putc(data, stdout);
		fflush(stdout);
	}
	mem[addr] = data;
}


void wait_us(unsigned int us){
	LARGE_INTEGER frequency, count, tmp;
	
	if (!QueryPerformanceFrequency(&frequency)) {
		return;
	}
	QueryPerformanceCounter(&count);
	for(;;){
		QueryPerformanceCounter(&tmp);
		double elapsedSeconds = static_cast<double>(tmp.QuadPart - count.QuadPart)
			/ frequency.QuadPart;
		if(elapsedSeconds*1000000 > us){
			return;
		}
	}
}

long long Get100usCount(){
	LARGE_INTEGER frequency, count;
	
	if (!QueryPerformanceFrequency(&frequency)) {
		return 0;
	}
	QueryPerformanceCounter(&count);
	double elapsedSeconds = static_cast<double>(count.QuadPart)
	   / frequency.QuadPart;
	return (long long)(elapsedSeconds*10000.0); 
}


// �t�@�C���I���_�C�A���O��\�����ăp�X���擾����֐�
bool OpenFileDialog(HWND hwnd, char* filePath, DWORD filePathSize)
{
    OPENFILENAMEA ofn = {};
    
    // �\���̂̏�����
    ofn.lStructSize = sizeof(OPENFILENAMEA);
    ofn.hwndOwner = hwnd;                  // �e�E�B���h�E�̃n���h��
    ofn.lpstrFile = filePath;             // �I�����ꂽ�t�@�C���p�X���i�[�����o�b�t�@
    ofn.lpstrFile[0] = '\0';               // ������
    ofn.nMaxFile = filePathSize;          // �o�b�t�@�T�C�Y
    ofn.lpstrFilter = "���ׂẴt�@�C�� (*.*)\0*.*\0�e�L�X�g�t�@�C�� (*.txt)\0*.txt\0"; // �t�B���^�[
    ofn.nFilterIndex = 1;                 // �f�t�H���g�̃t�B���^�[�ԍ�
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;

    // �u�t�@�C�����J���v�_�C�A���O��\��
    if (GetOpenFileNameA(&ofn))
    {
        return true; // �t�@�C�����I�����ꂽ
    }
    return false; // �L�����Z�����ꂽ
}


int exec(FILE *fplog){
	int op, e_addr, tmp, M, oldC, api;
	unsigned char code;
	uint16_t sum, diff, ptr, low16, high16;
	uint8_t low, high;

	code = mem[pc++];
	switch(code){
	case 0xa9:                          // LDA #$10
		A = ppu_read(pc++);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xa5:                          // LDA $10
		e_addr = mem[pc++];
		A = ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xa7:                          // LAX $10
		e_addr = mem[pc++];
		A = ppu_read(e_addr);
		X = A;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xb5:                          // LDA $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		A = ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xb7:                          // LDX $10,Y
		e_addr = (mem[pc++]+Y) & 0xff;
		A = ppu_read(e_addr);
		X = A;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xad:                          // LDA $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		A = ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xaf:                          // LAX $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		A = ppu_read(e_addr);
		X = A;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xbd:                          // LDA $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		A = ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xb9:                          // LDA $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		A = ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xbf:                          // LAX $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		A = ppu_read(e_addr);
		X = A;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xa1:                          // LDA ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		A = ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xa3:                          // LAX ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		A = ppu_read(e_addr);
		X = A;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xb1:                          // LDA ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		A = ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0xb3:                          // LAX ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		A = ppu_read(e_addr);
		X = A;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	;
	case 0xa2:                          // LDX #$10
		X = mem[pc++];
		Z = ((X & 0xff)==0);
		N = (X & 0x80) != 0;
		break;
	case 0xa6:                          // LDX $10
		e_addr = mem[pc++];
		X = ppu_read(e_addr);
		Z = ((X & 0xff)==0);
		N = (X & 0x80) != 0;
		break;
	case 0xb6:                          // LDX $10,Y
		e_addr = (mem[pc++]+Y) & 0xff;
		X = ppu_read(e_addr);
		Z = ((X & 0xff)==0);
		N = (X & 0x80) != 0;
		break;
	case 0xae:                          // LDX $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		X = ppu_read(e_addr);
		Z = ((X & 0xff)==0);
		N = (X & 0x80) != 0;
		break;
	case 0xbe:                          // LDX $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		X = ppu_read(e_addr);
		Z = ((X & 0xff)==0);
		N = (X & 0x80) != 0;
		break;
	;
	case 0xa0:                          // LDY #$10
		Y = mem[pc++];
		Z = ((Y & 0xff)==0);
		N = (Y & 0x80) != 0;
		break;
	case 0xa4:                          // LDY $10
		e_addr = mem[pc++];
		Y = mem[e_addr];
		Z = ((Y & 0xff)==0);
		N = (Y & 0x80) != 0;
		break;
	case 0xb4:                          // LDY $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		Y = ppu_read(e_addr);
		Z = ((Y & 0xff)==0);
		N = (Y & 0x80) != 0;
		break;
	case 0xac:                          // LDY $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		Y = ppu_read(e_addr);
		Z = ((Y & 0xff)==0);
		N = (Y & 0x80) != 0;
		break;
	case 0xbc:                          // LDY $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		Y = ppu_read(e_addr);
		Z = ((Y & 0xff)==0);
		N = (Y & 0x80) != 0;
		break;
	;
	case 0x85:                          // STA $10
		e_addr = mem[pc++];
		mem[e_addr] = A;
		break;
	case 0x87:                          // SAX $10
		e_addr = mem[pc++];
		mem[e_addr] = A & X;
		break;
	case 0x95:                          // STA $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		mem[e_addr] = A;
		break;
	case 0x97:                          // SAX $10,Y
		e_addr = (mem[pc++]+Y) & 0xff;
		mem[e_addr] = A & X;
		break;
	case 0x8d:                          // STA $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		mem[e_addr] = A;
		ppu_write(e_addr, A);
		break;
	case 0x8f:                          // SAX $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		mem[e_addr] = A & X;
		ppu_write(e_addr, mem[e_addr]);
		break;
	case 0x9d:                          // STA $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		mem[e_addr] = A;
		ppu_write(e_addr, A);
		break;
	case 0x99:                          // STA $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		mem[e_addr] = A;
		ppu_write(e_addr, A);
		break;
	case 0x81:                          // STA ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		mem[e_addr] = A;
		ppu_write(e_addr, A);
		break;
	case 0x83:                          // SAX ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		mem[e_addr] = A & X;
		ppu_write(e_addr, mem[e_addr]);
		break;
	case 0x91:                          // STA ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		mem[e_addr] = A;
		ppu_write(e_addr, A);
		break;
	;
	case 0x86:                          // STX $10
		e_addr = mem[pc++];
		mem[e_addr] = X;
		break;
	case 0x96:                          // STX $10,Y
		e_addr = (mem[pc++]+Y) & 0xff;
		mem[e_addr] = X;
		break;
	case 0x8e:                          // STX $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		mem[e_addr] = X;
		ppu_write(e_addr, X);
		break;
	;
	case 0x84:                          // STY $10
		e_addr = mem[pc++];
		mem[e_addr] = Y;
		break;
	case 0x94:                          // STY $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		mem[e_addr] = Y;
		break;
	case 0x8c:                          // STY $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		mem[e_addr] = Y;
		ppu_write(e_addr, Y);
		break;
	;
	case 0x69:                          // ADC #$10
		M = mem[pc++];
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x65:                          // ADC $10
		e_addr = mem[pc++];
		M = mem[e_addr];
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x67:                          // RRA $10
		e_addr = mem[pc++];
		oldC = C;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		M = mem[e_addr];
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x75:                          // ADC $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		M = mem[e_addr];
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x77:                          // RRA $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		oldC = C;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		M = mem[e_addr];
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x6d:                          // ADC $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x6f:                          // RRA $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		oldC = C;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x7d:                          // ADC $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x7f:                          // RRA $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		oldC = C;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x79:                          // ADC $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x7b:                          // RRA $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		oldC = C;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x61:                          // ADC ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x63:                          // RRA ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		oldC = C;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x71:                          // ADC ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	case 0x73:                          // RRA ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		oldC = C;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		M = ppu_read(e_addr);
		sum = A + M + C;
		C = (sum > 0xFF);
		Z = ((sum & 0xFF) == 0);
		N = (sum & 0x80) != 0;
		V = (~(A ^ M) & (A ^ sum) & 0x80) != 0;
		A = sum;
		break;
	;
	case 0xe9:                          // SBC #$10
	case 0xeb:
		M = mem[pc++];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xe5:                          // SBC $10
		e_addr = mem[pc++];
		M = mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xe7:                          // ISB $10
		e_addr = mem[pc++];
		M = ++mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xf5:                          // SBC $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		M = mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xf7:                          // ISB $12,X
		e_addr = (mem[pc++]+X) & 0xff;
		M = ++mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xed:                          // SBC $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = ppu_read(e_addr);
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xef:                          // ISB $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = ++mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xfd:                          // SBC $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		M = ppu_read(e_addr);
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xff:                          // ISB $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		M = ++mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xf9:                          // SBC $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		M = ppu_read(e_addr);
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xfb:                          // ISB $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		M = ++mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xe1:                          // SBC ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		M = ppu_read(e_addr);
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xe3:                          // ISB ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		M = ++mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xf1:                          // SBC ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		M = ppu_read(e_addr);
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	case 0xf3:                          // ISB ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		M = ++mem[e_addr];
		diff = A - M - (1 - C);
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		V = ((A ^ M) & (A ^ diff) & 0x80) != 0;
		A = diff;
		break;
	;
	case 0x29:                          // AND #$10
		A &= mem[pc++];
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x25:                          // AND $10
		e_addr = mem[pc++];
		A &= mem[e_addr];
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x27:                          // RLA $10
		e_addr = mem[pc++];
		oldC = C;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x35:                          // AND $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x37:                          // RLA $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		oldC = C;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x2d:                          // AND $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x2f:                          // RLA $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		oldC = C;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x3d:                          // AND $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x3f:                          // RLA $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		oldC = C;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x39:                          // AND $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x3b:                          // RLA $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		oldC = C;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x21:                          // AND ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x23:                          // RLA ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		oldC = C;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x31:                          // AND ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x33:                          // RLA ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		oldC = C;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		A &= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	;
	case 0x09:                          // ORA #$10
		A |= mem[pc++];
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x05:                          // ORA $10
		e_addr = mem[pc++];
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x07:                          // SLO $10
		e_addr = mem[pc++];
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		A |= mem[e_addr];
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x15:                          // ORA $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x17:                          // SLO $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x0d:                          // ORA $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x0f:                          // SLO $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x1d:                          // ORA $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x1f:                          // SLO $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x19:                          // ORA $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x1b:                          // SLO $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x01:                          // ORA ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x03:                          // SLO ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x11:                          // ORA ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x13:                          // SLO ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		A |= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	;
	case 0x49:                          // EOR #$10
		A ^= mem[pc++];
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x45:                          // EOR $10
		e_addr = mem[pc++];
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x47:                          // SRE $10
		e_addr = mem[pc++];
		C = mem[e_addr] & 0x01;
		mem[e_addr] >>= 1;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x55:                          // EOR $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x57:                          // SRE $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		C = mem[e_addr] & 0x01;
		mem[e_addr] >>= 1;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x4d:                          // EOR $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x4f:                          // SRE $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		C = mem[e_addr] & 0x01;
		mem[e_addr] >>= 1;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x5d:                          // EOR $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x5f:                          // SRE $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		C = mem[e_addr] & 0x01;
		mem[e_addr] >>= 1;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x59:                          // EOR $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x5b:                          // SRE $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		C = mem[e_addr] & 0x01;
		mem[e_addr] >>= 1;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x41:                          // EOR ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x43:                          // SRE ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		C = mem[e_addr] & 0x01;
		mem[e_addr] >>= 1;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x51:                          // EOR ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x53:                          // SRE ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		C = mem[e_addr] & 0x01;
		mem[e_addr] >>= 1;
		A ^= ppu_read(e_addr);
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	;
	case 0xc9:                          // CMP #$10
		M = mem[pc++];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xc5:                          // CMP $10
		e_addr = mem[pc++];
		M = ppu_read(e_addr);
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xc7:                          // DCP $10
		e_addr = mem[pc++];
		M = --mem[e_addr];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xd5:                          // CMP $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		M = ppu_read(e_addr);
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xd7:                          // DCP $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		M = --mem[e_addr];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xcd:                          // CMP $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = ppu_read(e_addr);
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xcf:                          // DCP $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = --mem[e_addr];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xdd:                          // CMP $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		M = ppu_read(e_addr);
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xdf:                          // DCP $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		M = --mem[e_addr];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xd9:                          // CMP $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		M = ppu_read(e_addr);
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xdb:                          // DCP $1234,Y
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + Y) & 0xffff;
		pc += 2;
		M = --mem[e_addr];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xc1:                          // CMP ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		M = ppu_read(e_addr);
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xc3:                          // DCP ($12,X)
		op = (mem[pc++]+X) & 0xff;
		e_addr = mem[op] + mem[(op+1)&0xff]*256;
		M = --mem[e_addr];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xd1:                          // CMP ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		M = ppu_read(e_addr);
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xd3:                          // DCP ($12),Y
	    op = mem[pc++];
		e_addr = (mem[op] + mem[(op+1)&0xff]*256 + Y) & 0xffff;
		M = --mem[e_addr];
		diff = A - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	;
	case 0xe0:                          // CPX #$10
		M = mem[pc++];
		diff = X - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xe4:                          // CPX $10
		e_addr = mem[pc++];
		M = ppu_read(e_addr);
		diff = X - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xec:                          // CPX $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = ppu_read(e_addr);
		diff = X - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	;
	case 0xc0:                          // CPY #$10
		M = mem[pc++];
		diff = Y - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xc4:                          // CPY $10
		e_addr = mem[pc++];
		M = ppu_read(e_addr);
		 diff = Y - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	case 0xcc:                          // CPY $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = ppu_read(e_addr);
		diff = Y - M;
		C = (diff < 0x100);  // �؂�Ȃ��Ȃ�1
		Z = ((diff & 0xFF) == 0);
		N = (diff & 0x80) != 0;
		break;
	;
	case 0xe6:                          // INC $10
		e_addr = mem[pc++];
		mem[e_addr]++;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0xf6:                          // INC $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		mem[e_addr]++;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0xee:                          // INC $1234
		e_addr = *(unsigned short*)&mem[pc];
		mem[e_addr]++;
		pc += 2;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0xfe:                          // INC $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		mem[e_addr]++;
		pc += 2;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	;
	case 0xc6:                          // DEC $10
		e_addr = mem[pc++];
		mem[e_addr]--;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0xd6:                          // DEC $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		mem[e_addr]--;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0xce:                          // DEC $1234
		e_addr = *(unsigned short*)&mem[pc];
		mem[e_addr]--;
		pc += 2;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0xde:                          // DEC $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		mem[e_addr]--;
		pc += 2;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	;
	case 0xe8:                          // INX
		X++;
		Z = ((X & 0xff)==0);
		N = (X & 0x80) != 0;
		break;
	case 0xc8:                          // INY
		Y++;
		Z = ((Y & 0xff)==0);
		N = (Y & 0x80) != 0;
		break;
	case 0xca:                          // DEX
		X--;
		Z = ((X & 0xff)==0);
		N = (X & 0x80) != 0;
		break;
	case 0x88:                          // DEY
		Y--;
		Z = ((Y & 0xff)==0);
		N = (Y & 0x80) != 0;
		break;
	;
	case 0x0a:                          // ASL A
		C = (A & 0x80) != 0;
		A <<= 1;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x06:                          // ASL $10
		e_addr = mem[pc++];
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x16:                          // ASL $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x0e:                          // ASL $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x1e:                          // ASL $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	;
	case 0x4a:                          // LSR  A
		C = (A & 0x01) != 0;
		A >>= 1;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x46:                          // LSR  $10
		e_addr = mem[pc++];
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x56:                          // LSR  $10,X
		e_addr = (mem[pc++]+X) & 0xff;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x4e:                          // LSR  $1234
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x5e:                          // LSR  $1234,X
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	;
	case 0x2a:                          // ROL  A
		oldC = C;
		C = (A & 0x80) != 0;
		A <<= 1;
		A |= oldC;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x26:                          // ROL  $10
		oldC = C;
		e_addr = mem[pc++];
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x36:                          // ROL  $10,X
		oldC = C;
		e_addr = (mem[pc++]+X) & 0xff;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x2e:                          // ROL  $1234
		oldC = C;
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x3e:                          // ROL  $1234,X
		oldC = C;
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		C = (mem[e_addr] & 0x80) != 0;
		mem[e_addr] <<= 1;
		mem[e_addr] |= oldC;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	;
	case 0x6a:                          // ROR A
		oldC = C;
		C = (A & 0x01) != 0;
		A >>= 1;
		A |= oldC<<7;
		Z = ((A & 0xff)==0);
		N = (A & 0x80) != 0;
		break;
	case 0x66:                          // ROR $10
		oldC = C;
		e_addr = mem[pc++];
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x76:                          // ROR $10,X
		oldC = C;
		e_addr = (mem[pc++]+X) & 0xff;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x6e:                          // ROR $1234
		oldC = C;
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	case 0x7e:                          // ROR $1234,X
		oldC = C;
		e_addr = (mem[pc] + mem[(pc+1)&0xffff]*256 + X) & 0xffff;
		pc += 2;
		C = (mem[e_addr] & 0x01) != 0;
		mem[e_addr] >>= 1;
		mem[e_addr] |= oldC<<7;
		Z = ((mem[e_addr] & 0xff)==0);
		N = (mem[e_addr] & 0x80) != 0;
		break;
	;
	case 0xaa:                          // TAX
		X = A;
		break;
	case 0xa8:                          // TAY
		Y = A;
		break;
	case 0x8a:                          // TXA
		A = X;
		Z = A==0;
		N = (A & 0x80) != 0;
		break;
	case 0x98:                          // TYA
		A = Y;
		Z = A==0;
		N = (A & 0x80) != 0;
		break;
	;
	case 0xf0:                          // BEQ $1234 ... pc���� +127�`-128
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(Z) pc = e_addr;
		break;
	case 0xd0:                          // BNE $1234
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(!Z) pc = e_addr;
		break;
	case 0xb0:                          // BCS $1234
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(C) pc = e_addr;
		break;
	case 0x90:                          // BCC $1234
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(!C) pc = e_addr;
		break;
	case 0x30:                          // BMI $1234
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(N) pc = e_addr;
		break;
	case 0x10:                          // BPL $1234
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(!N) pc = e_addr;
		break;
	case 0x70:                          // BVS $1234
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(V) pc = e_addr;
		break;
	case 0x50:                          // BVC $1234
		tmp = (char)mem[pc++];
		e_addr = pc + tmp;
		if(!V) pc = e_addr;
		break;
	;
	case 0x4c:                          // JMP $1234
		e_addr = mem[pc] | (mem[pc+1] << 8);
		pc = e_addr;
		break;
	case 0x6c:                          // JMP ($1234)
		ptr = mem[pc] | (mem[pc+1] << 8);
		low16 = mem[ptr];
		high16 = mem[(ptr & 0xFF00) | ((ptr + 1) & 0x00FF)];
		pc = low16 | (high16 << 8);
		break;
	case 0x20:                          // JSR $1234
		e_addr = *(unsigned short*)&mem[pc];
		mem[0x100+ (sp--)] = ((pc+1)>>8);   //AAAAA
		mem[0x100+ (sp--)] = (pc+1) & 0xff;
		pc = e_addr;
		break;
	case 0x60:                          // RTS
		low = mem[0x100 + (++sp)];
		high = mem[0x100 + (++sp)];
		pc = (high << 8 | low) + 1;
		break;
	;
	case 0x48:                          // PHA  ... push A
		mem[0x100+ (sp--)] = A;
		break;
	case 0x08:                          // PHP  ... push F
		mem[0x100+ (sp--)] = P.f;
		break;
	case 0x68:                          // PLA  ... pop A
		A = mem[0x100+ (++sp)];
		Z = A==0;
		N = (A & 0x80) != 0;
		break;
	case 0x28:                          // PLP  ... pop F
		P.f = mem[0x100+ (++sp)];
		B = 1;
		break;
	;
	case 0x18:                          // CLC
		C = 0;
		break;
	case 0x38:                          // SEC
		C = 1;
		break;
	case 0x58:                          // CLI
		I = 0;
		break;
	case 0x78:                          // SEI
		I = 1;
		break;
	case 0xb8:                          // CLV
		V = 0;
		break;
	case 0xd8:                          // CLD
	    D = 0;
		break;
	case 0xf8:                          // (SED)
		D = 1;
		break;
	;
	case 0xea:                          // NOP
		break;
	case 0x00:                          // BRK
		pc++;
		mem[0x100+ (sp--)] = pc>>8;
		mem[0x100+ (sp--)] = pc;
		
		mem[0x100+ (sp--)] = P.f | 0x10;
		
		I = 1;
		pc = *(unsigned short*)&mem[0xfffe];
		break;

#if 0
		api = mem[pc++];
		if(api==1){
			putchar(A);
			fflush(stdout);
		}
		else if(api==2){
			A = _getch();
			if(A==0x03){        // cntl-C
				return 1;
			}
		}
		else if(api==3){
			int size = A;
			char* buf = (char*)&mem[X*256+Y];
			char* ret = fgets(buf, size, stdin);
			A = ret==0 ? 0 : 1;
		}
		else if(api==4){
			char* buf = (char*)&mem[X*256+Y];
			puts(buf);
			fflush(stdout);
		}
		break;
#endif
	case 0x02:                          // INT3
		int i;
		
		printf("break at %04x\n", pc-1);
		for(i=0; i<3; i++){
			if(b_point[i].flag && (pc-1)==b_point[i].addr){
				int addr = pc-1;
				b_point[i].flag = 0;
				mem[addr] = b_point[i].code;
				pc = pc-1;
				break;
			}
		}
		return 2;
	case 0x40:                          // RTI
		P.f = mem[0x100+ (++sp)];
		B = 1;
		pc = mem[0x100+ (++sp)];
		pc |= mem[0x100+ (++sp)]<<8;
		break;
	case 0x24:                          // BIT zp
		e_addr = mem[pc++];
		M = ppu_read(e_addr);
		Z = (A & M)==0;
		N = (M & 0x80) ? 1 : 0;
		V = (M & 0x40) ? 1 : 0;
		break;
	case 0x2c:                          // BIT abs
		e_addr = *(unsigned short*)&mem[pc];
		pc += 2;
		M = ppu_read(e_addr);
		Z = (A & M)==0;
		N = (M & 0x80) ? 1 : 0;
		V = (M & 0x40) ? 1 : 0;
		break;
	case 0x9a:                          // TXS
	    sp = X;
	    break;
	case 0xba:                          // TSX
		X = sp;
		Z = X==0;
		N = (X & 0x80) != 0;
		break;
	case 0x1a:   // NOP
	case 0x3a:
	case 0x5a:
	case 0x7a:
	case 0xda:
	case 0xfa:
		break;
	case 0x04: { // NOP zeropage
	case 0x44:
	case 0x64:
	
	case 0x14:   // NOP zp,X
	case 0x34:
	case 0x54:
	case 0x74:
	case 0xd4:
	case 0xf4:
	
	case 0x80:
	    uint8_t zp = mem[pc++];
	    zp = mem[zp];        // ���@�͓ǂݍ��ނ��g��Ȃ�
	    break;
	}
	case 0x0c:
	case 0x1c:
	case 0x3c:
	case 0x5c:
	case 0x7c:
	case 0xdc:
	case 0xfc:
	{
		uint16_t abs = mem[pc] + mem[pc+1]*256;
		pc +=2;
		uint8_t d = mem[abs];
		break;
	} 
	;
	default:
		fprintf(fplog, "*** illegal code %04x:%02x\n", pc-1, code);
		break;
	}
	return 0;                           // normal end
}

// linebufp ���當������P�u���b�N��荞�ݕԂ��Asymbuf[] �ɓ����
// �u���b�N�̋�؂�L���̓X�y�[�X��','��'\r'��'\n' NULL
char *getsym(){
  int flag=0;
  char *pt;
  // �擪�̃X�y�[�X���X�L�b�v����
  while(*linebufp==' ' || *linebufp==',') linebufp++;
  
  pt = symbuf;
  while(1){
    if(flag==0){
      if(*linebufp==' ' || *linebufp==','){
        break;
      }
    }
    if(*linebufp=='\0' || *linebufp=='\r' || *linebufp=='\n'){
      break;
    }
    if(*linebufp=='\''){
      flag = !flag;
    }
    *pt++ = *linebufp++;
  }
  *pt = '\0';
  return symbuf;
}

unsigned short gethex(char * str){
  unsigned short numb = 0;
  
  for(;;){
    if(*str>='0' && *str<='9'){
      numb = (numb)*16 + *str-'0';
    }
    else if(*str>='A' && *str<='F'){
      numb = (numb)*16 + *str-'A'+10;
    }
    else if(*str>='a' && *str<='f'){
      numb = (numb)*16 + *str-'a'+10;
    }
    else{
      return numb;
    }
    str++;
  }
}


void nestest(FILE *fplog){
	pc = 0xc000;
	A = 0;
	X = 0;
	Y = 0;
	P.f = 0x24;
	sp = 0xfd;
	FILE *fp = fopen("nestest.log", "r");
	char *pt;
	int ret=0;
	if(fp==0){
		fprintf(stderr, "*** file open error nestest.log\n");
		return;
	}
	for(;; ret=exec(fplog)){
		
		
		
//		if(pc>=0xc852 && pc<=0xc85c){
//			fprintf(stdout, "A=%02x X=%02x Y=%02x P=%02x sp=%02x\n", A, X, Y, P.f, sp);
//			dasm(stdout, pc, mem);
//		}
		
		
		
		if(ret){
			break;
		}
		if(fgets(linebuf, sizeof(linebuf), fp)==0){
			fprintf(fplog, "=== end of test\n");
			break;
		}
		if(gethex(linebuf) != pc){
			fprintf(fplog, "..............................................................\n");
			fprintf(fplog, "referrence: %s\n", linebuf);
			fprintf(fplog, "A=%02x X=%02x Y=%02x P=%02x sp=%02x\n", A, X, Y, P.f, sp);
			dasm(fplog, pc, mem);
			continue;
		}
		if((pt=strstr(linebuf, "A:"))==0){
			fprintf(fplog, "*** illegal line: %s\n", linebuf);
			break;
		}
		if(gethex(pt+2) != A){
			fprintf(fplog, "referrence: %s\n", linebuf);
			fprintf(fplog, "A=%02x X=%02x Y=%02x P=%02x sp=%02x\n", A, X, Y, P.f, sp);
			dasm(fplog, pc, mem);
			continue;
		}
		if((pt=strstr(linebuf, "X:"))==0){
			fprintf(fplog, "*** illegal line: %s\n", linebuf);
			break;
		}
		if(gethex(pt+2) != X){
			fprintf(fplog, "referrence: %s\n", linebuf);
			fprintf(fplog, "A=%02x X=%02x Y=%02x P=%02x sp=%02x\n", A, X, Y, P.f, sp);
			dasm(fplog, pc, mem);
			continue;
		}
		if((pt=strstr(linebuf, "Y:"))==0){
			fprintf(fplog, "*** illegal line: %s\n", linebuf);
			break;
		}
		if(gethex(pt+2) != Y){
			fprintf(fplog, "referrence: %s\n", linebuf);
			fprintf(fplog, "A=%02x X=%02x Y=%02x P=%02x sp=%02x\n", A, X, Y, P.f, sp);
			dasm(fplog, pc, mem);
			continue;
		}
		if((pt=strstr(linebuf, "P:"))==0){
			fprintf(fplog, "*** illegal line: %s\n", linebuf);
			break;
		}
		if((gethex(pt+2) & 0xcf) != (P.f & 0xcf)){
			fprintf(fplog, "referrence: %s\n", linebuf);
			fprintf(fplog, "A=%02x X=%02x Y=%02x P=%02x sp=%02x\n", A, X, Y, P.f, sp);
			dasm(fplog, pc, mem);
			continue;
		}
		if((pt=strstr(linebuf, "SP:"))==0){
			fprintf(fplog, "*** illegal line: %s\n", linebuf);
			break;
		}
		if(gethex(pt+3) != sp){
			fprintf(fplog, "referrence: %s\n", linebuf);
			fprintf(fplog, "A=%02x X=%02x Y=%02x P=%02x sp=%02x\n", A, X, Y, P.f, sp);
			dasm(fplog, pc, mem);
			continue;
		}
	}
	
	fclose(fp);
}


int main(){
	int dasm_pc, dasm_len=10;
	
	P.f = 0x34;
	sp = 0;
	while(1){
		printf(">");fflush(stdout);
		fgets(linebuf, sizeof(linebuf), stdin);
		linebuf[strlen(linebuf)-1] = '\0';
		linebufp = linebuf;
		getsym();
		if(strcmp(symbuf, "help")==0){
			printf(">load\n");
			printf(">go\n");
			printf(">s [<step��>]\n");
			printf(">b <addr>\n");
			printf(">bclr\n");
			printf(">blistup\n");
			printf(">regs\n");
			printf(">dump [<addr>[<byte>]]\n");
			printf(">dasm [<addr>[<len>]]\n");
			printf(">pc <addr>\n");
			printf(">A <value>\n");
			printf(">X <value>\n");
			printf(">Y <value>\n");
		}
		else if(strcmp(symbuf, "load")==0){
			FILE *fp;
			char buf[65*1024];
			int len;
			HWND hwnd = GetConsoleWindow();

			OpenFileDialog(hwnd, linebuf, (DWORD)sizeof(linebuf));
//			getsym();
			if((fp=fopen(linebuf, "rb"))==0){
				fprintf(stderr, "*** file open error %s\n", symbuf);
			}

			len = fread(buf, 1, sizeof(buf), fp);

			if(len==0x10000){
				memcpy(mem, buf, 0x10000);
				fclose(fp);
				pc = dasm_pc = *(short*)&mem[0xfffc];
			}
			else{
				fprintf(stderr, "*** ROM size error len=%d\n", len);
				fclose(fp);
			}
		}
		else if(strcmp(symbuf, "go")==0){
			while(exec(stdout)==0){
			}
			dasm_pc = pc;
		}
		else if(strcmp(symbuf, "s")==0){
			int numb, ret;
			getsym();
			numb = atoi(symbuf);
			if(numb==0) numb = 1;
			for(int i=0; i<numb; i++){
				dasm_pc = dasm(stdout, pc, mem);
				ret = exec(stdout);
				printf("next %04x:%02x ", pc, mem[pc]);fflush(stdout);
				printf("A=%02x X=%02x Y=%02x sp=%02x P=%02x ", A, X, Y, sp, P.f);
				printf("C%dZ%dN%dV%dI%d\n", C, Z, N, V, I);
				if(ret){
					break;
				}
				
			}
		}
		else if(strcmp(symbuf, "NMI")==0){
			mem[0x100+ (sp--)] = pc>>8;
			mem[0x100+ (sp--)] = pc;
			mem[0x100+ (sp--)] = P.f & ~0x10;
			pc = *(unsigned short*)&mem[0xfffa];
		}
		else if(strcmp(symbuf, "b")==0){
			int i;
			unsigned short addr;
			getsym();
			addr = gethex(symbuf);
			for(i=0; i<3; i++){
				if(b_point[i].flag==0){
					b_point[i].flag = 1;
					b_point[i].code = mem[addr];
					b_point[i].addr = addr;
					mem[addr] = 0x02;
					break;
				}
			}
			if(i==3){
				printf("*** break point buffer over\n");
			}
		}
		else if(strcmp(symbuf, "bclr")==0){
			for(int i=0; i<3; i++){
				if(b_point[i].flag){
					b_point[i].flag = 0;
					mem[b_point[i].addr] = b_point[i].code;
				}
			}
			printf("=== break point all cleared\n");
		}
		else if(strcmp(symbuf, "blistup")==0){
			for(int i=0; i<3; i++){
				printf("No.%d ", i+1);
				if(b_point[i].flag){
					printf("addr=0x%04x code=0x%02x\n", b_point[i].addr, b_point[i].code);
				}
				else{
					printf("<no break point>\n");
				}
			}
		}
		else if(strcmp(symbuf, "regs")==0){
			printf("A=%02x X=%02x Y=%02x sp=%02x P=%02x ", A, X, Y, sp, P.f);
			printf("C%dZ%dN%dV%dI%d\n", C, Z, N, V, I);
		}
	    else if(strcmp(symbuf, "dump")==0){
	      static unsigned short addr=0;
	      int byte = 64;
	      
	      getsym();
	      if(symbuf[0]){
	        addr = gethex(symbuf);
	        getsym();
	        if(symbuf[0]){
	          byte = atoi(symbuf);
	        }
	      }
	      for(int i=0; ; i++){
	        printf("%04x: ", addr+i*16);
	        for(int j=0; j<16; j++){
	          printf("%02x ", mem[addr+i*16+j]);
	        }
	        printf("\n");
	        if((i+1)*16 >= byte){
	          break;
	        }
	      }
	      addr += byte;
	    }
	    else if(strcmp(symbuf, "dasm")==0){
			getsym();
			if(symbuf[0]){
				dasm_pc = gethex(symbuf);
				getsym();
				if(symbuf[0]){
					dasm_len = atoi(symbuf);
				}
			}
			for(int i=0; i<dasm_len; i++){
				dasm_pc = dasm(stdout, dasm_pc, mem);
			}
		}
		else if(strcmp(symbuf, "pc")==0){
			getsym();
			pc = gethex(symbuf);
		}
		else if(strcmp(symbuf, "A")==0){
			getsym();
			A = gethex(symbuf);
		}
		else if(strcmp(symbuf, "X")==0){
			getsym();
			X = gethex(symbuf);
		}
		else if(strcmp(symbuf, "Y")==0){
			getsym();
			Y = gethex(symbuf);
		}
		else{
			fprintf(stderr,"*** undefined command %s\n", symbuf);
		}
	}
}
